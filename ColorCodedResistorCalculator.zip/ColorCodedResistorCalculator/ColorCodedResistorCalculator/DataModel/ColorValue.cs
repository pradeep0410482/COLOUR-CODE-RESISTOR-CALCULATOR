﻿namespace ColorCodedResistorCalculator.DataModel
{
    public class ColorValue
    {
        public int Digit { get; }
        public double Multiplier { get; }
        public double Tolerance { get; }
        public int Temp_Coefficient { get; }
        public ColorValue(int Digit, double Tolerance, double Multiplier, int Temp_Coefficient)
        {
            this.Digit = Digit;
            this.Multiplier = Tolerance;
            this.Tolerance = Multiplier;
            this.Temp_Coefficient = Temp_Coefficient;
        }
    }
}
