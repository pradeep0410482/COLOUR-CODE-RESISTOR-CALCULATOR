﻿namespace ColorCodedResistorCalculator.DataModel
{
    public class Result
    {
        public double Resistance { get; }
        public double Tolerance { get; }
        public double MinResistance { get; }
        public double MaxResistance { get; }
        public int Temp_Coefficient { get; }
        public Result(double Resistance, double Tolerance, double MinResistance, double MaxResistance, int Temp_Coefficient)
        {
            this.Resistance = Resistance;
            this.Tolerance = Tolerance;
            this.MinResistance = MinResistance;
            this.MaxResistance = MaxResistance;
            this.Temp_Coefficient = Temp_Coefficient;
        }
    }
}
