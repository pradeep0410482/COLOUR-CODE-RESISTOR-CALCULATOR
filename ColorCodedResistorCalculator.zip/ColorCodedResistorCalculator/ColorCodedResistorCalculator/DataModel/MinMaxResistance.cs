﻿using System;
namespace ColorCodedResistorCalculator.DataModel
{
    public struct MinMaxResistance
    {
        public double Min { get; }
        public double Max { get; }
        public MinMaxResistance(double Min, double Max)
        {
            this.Min = Min;
            this.Max = Max;
        }
    }
}
