﻿using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ColorCodedResistorCalculator
{
    public class ColorControl : Calculate
    {
        readonly Button[] coloredButtons;
        readonly PictureBox[] guideImages;
        readonly PictureBox _1stDigitImg, _2ndDigitImg, _3rdDigitImg, multiplierImg, toleranceImg, tempCoefficientImg;
        readonly Label guideLabel;
        readonly Panel[][] allPanelBands;
        readonly Button undo;
        TextBox selectedColorsTxtBox;
        List<string> selectedColorLst = new List<string>();

        public ColorControl(Button[] coloredButtons, PictureBox[] guideImages, Label guideLabel, Button calculate, Button undo, Panel[][] allPanelBands, TextBox selectedColorsTxtBox) : base(calculate)
        {
            this.coloredButtons = coloredButtons;
            this.guideImages = guideImages;
            this.guideLabel = guideLabel;
            this.allPanelBands = allPanelBands;
            this.undo = undo;
            this.selectedColorsTxtBox = selectedColorsTxtBox;
            _1stDigitImg = this.guideImages[0];
            _2ndDigitImg = this.guideImages[1];
            _3rdDigitImg = this.guideImages[2];
            multiplierImg = this.guideImages[3];
            toleranceImg = this.guideImages[4];
            tempCoefficientImg = this.guideImages[5];
            undo.Enabled = false;
            DisableColoredBtns();
        }

        #region Assigning of colors inside the Resistor
        int indexColors = -1;
        readonly Color emptyColor = Color.FromKnownColor(KnownColor.Control);
        public void AddColor(Color selectedColor, Panel[] panelBand, char band) 
        {
            this.band = band;
            int maximum_index = panelBand.Count() - 1;
            indexColors++;
            if (indexColors == maximum_index)
            { 
                DisableColoredBtns();
                guideLabel.Text = string.Empty;
                DisableLastImg();   
                EnableCalculateBtn(true);
            }
            EnableUndoButton();
            panelBand[indexColors].BackColor = selectedColor;
            AddColorsToTxtBox();
            GuideAndColorFilterForAllBands();

            void AddColorsToTxtBox()
            {
                selectedColorLst.Add(selectedColor.Name);
                selectedColorsTxtBox.Text = string.Join(" ", selectedColorLst);
            } 
        }

        public void UndoColor(Panel[] panelBand, char band) 
        {
            this.band = band;
            indexColors--;
            if (indexColors <= -1)
            {
                indexColors = -1;
                undo.Enabled = false;
            }
            EnableCalculateBtn(false);
            panelBand[indexColors + 1].BackColor = emptyColor;
            UndoColorsFrmTxtBox();
            GuideAndColorFilterForAllBands();

            void UndoColorsFrmTxtBox()
            {
                selectedColorLst.RemoveAt(indexColors + 1);
                selectedColorsTxtBox.Text = string.Join(" ", selectedColorLst); 
            }
        }
        #endregion
        #region Controlling of Calculate and Undo button
        private void EnableCalculateBtn(bool enable) => calculate.Enabled = enable;
        private void EnableUndoButton()
        {
            if (undo.Enabled == false)
            {
                undo.Enabled = true;
            }
        }
        #endregion
        #region Reset
        public void Reset(char _band)
        {
            band = _band;
            ClrAllPanelBands();    
            GuideAndColorFilterForAllBands();
            EnableCalculateBtn(false);
            ClearSelectedColorsTxt();
            
            void ClrAllPanelBands()
            {
                indexColors = -1;
                var panelBands = from band in allPanelBands
                                     from panel in band
                                     where panel.BackColor != emptyColor
                                     select panel;

                foreach (var panel in panelBands)
                {
                    panel.BackColor = emptyColor;
                }
            }

            void ClearSelectedColorsTxt()
            {
                selectedColorLst.Clear();
                selectedColorsTxtBox.Text = "";
            }
        }

        #endregion
        #region Filtering the selection of colored buttons 
        public void GuideAndColorFilterForAllBands() 
        {
            switch (band)
            {
                case three_band: GuideAndColorFilter_3band(); break;
                case four_band: GuideAndColorFilter_4band(); break;
                case five_band: GuideAndColorFilter_5Band(); break;
                case six_band: GuideAndColorFilter_6Band(); break;
            }
        }

        private void GuideAndColorFilter_3band()
        {
            switch (indexColors)
            {
                case -1: // guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForFirstDigit();
                    break;
                case 0: // guide and color filter for second digit selection
                    EnableDigitColoredBtns();
                    GuideForSecondDigit();
                    break;
                case 1:// guide and color filter for multiplier selection
                    EnableMultiplierColoredButtons();
                    GuideImgMultiplier();
                    break;
            }
        }

        private void GuideAndColorFilter_4band()
        {
            switch (indexColors)
            {
                case -1: // guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForFirstDigit();
                    break;
                case 0: // guide and color filter for second digit selection
                    EnableDigitColoredBtns();
                    GuideForSecondDigit();
                    break;
                case 1:// guide and color filter for multiplier selection
                    EnableMultiplierColoredButtons();
                    GuideImgMultiplier();
                    break;
                case 2:// guide and color filter for tolerance selection
                    EnableToleranceColoredBtns();
                    GuideForTolerance();
                    break;
            }
        }

        private void GuideAndColorFilter_5Band()
        {
            switch (indexColors)
            {
                case -1:// guide and filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForFirstDigit();
                    break;
                case 0:// guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForSecondDigit();
                    break;
                case 1:// guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForThirdDigit();
                    break;
                case 2:// guide and color filter for multiplier
                    EnableMultiplierColoredButtons();
                    GuideImgMultiplier();
                    break;
                case 3:// guide and color filter for tolerance
                    EnableToleranceColoredBtns();
                    GuideForTolerance();
                    break;
            }
        }

        private void GuideAndColorFilter_6Band()
        {
            switch (indexColors)
            {
                case -1: // guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForFirstDigit();
                    break;
                case 0: // guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForSecondDigit();
                    break;
                case 1: // guide and color filter for first digit selection
                    EnableDigitColoredBtns();
                    GuideForThirdDigit();
                    break;
                case 2: // guide and color filter for multiplier
                    EnableMultiplierColoredButtons();
                    GuideImgMultiplier();
                    break;
                case 3: // guide and color filter for tolerance
                    EnableToleranceColoredBtns();
                    GuideForTolerance();
                    break;
                case 4: // guide and color filter for temp. coefficient
                    EnableTempCoefficientColoredBtns();
                    GuideForTempCoefficient();
                    break;
            }
        }
        #endregion 

        #region Selection guide for selecting the colors
        private void DisableLastImg()
        {
            if (band == six_band)
            {
                tempCoefficientImg.Visible = false;
            }
            else if (band == three_band)
            {
                multiplierImg.Visible = false;
            }
            else
            {
                toleranceImg.Visible = false;
            }
        } 
        private void GuideForFirstDigit()
        {
            ShowGuideImg(_1stDigitImg);
            guideLabel.Text = "Select a Color for First Digit";
        }
        private void GuideForSecondDigit()
        {
            ShowGuideImg(_2ndDigitImg);
            guideLabel.Text = "Select a Color for Second Digit";
        }
        private void GuideForThirdDigit()
        {
            ShowGuideImg(_3rdDigitImg);
            guideLabel.Text = "Select a Color for Third Digit";
        }
        private void GuideImgMultiplier()
        {
            ShowGuideImg(multiplierImg);
            guideLabel.Text = "Select a Color for Multiplier";
        }
        private void GuideForTolerance()
        {
            ShowGuideImg(toleranceImg);
            guideLabel.Text = "Select a Color for Tolerance";
        }
        private void GuideForTempCoefficient()
        {
            ShowGuideImg(tempCoefficientImg);
            guideLabel.Text = "Select a Color for Temperature Coefficient";
        }

        private void ShowGuideImg(PictureBox imgToBeVisible)
        {
            foreach (var guideImage in guideImages)
            {
                bool showSelectedImage = guideImage == imgToBeVisible;
                guideImage.Visible = (showSelectedImage) ? true : false; // if showSelectedImage is true then guideImage.Visible = true else: false / tnks for ternary operator
            }
        }
        #endregion
        #region Filters the colored buttons 
        //Thanks LINQ you are amazing!
        private void EnableDigitColoredBtns()
        {  //select a button that its backcolor is not equal to Gold and Silver then enable these colors
            var selectedBtns = coloredButtons.Where(c => c.BackColor != Color.Gold && c.BackColor != Color.Silver);
            EnableTheseColoredBtns(selectedBtns);
        }

        private void EnableMultiplierColoredButtons()
        {
            foreach (var selectedColoredButtons in coloredButtons)
            {
                selectedColoredButtons.Enabled = true;
            }
        }

        private void EnableToleranceColoredBtns()
        {   //select a button that its backcolor is not equal to black and white then enable these colors
            var selectedBtns = coloredButtons.Where(c => c.BackColor != Color.Black && c.BackColor != Color.White);
            EnableTheseColoredBtns(selectedBtns);
        }

        private void EnableTempCoefficientColoredBtns()
        {
            var selectedBtns = from button in coloredButtons
                                                      where button.BackColor != Color.White
                                                      && button.BackColor != Color.Gold
                                                      && button.BackColor != Color.Silver
                                                      select button;
            EnableTheseColoredBtns(selectedBtns);
        }

        private void EnableTheseColoredBtns(IEnumerable<Button> selected_buttons)
        {
            foreach(var coloredButton in coloredButtons)
            {
                if (selected_buttons.Contains(coloredButton))
                {
                    coloredButton.Enabled = true;
                }
                else if (!selected_buttons.Contains(coloredButton))
                {
                    coloredButton.Enabled = false;
                }
            }
        }

        private void DisableColoredBtns()
        {
            foreach (Button btn in coloredButtons)
            {
                btn.Enabled = false;
            }
        }
        #endregion
    }
}
