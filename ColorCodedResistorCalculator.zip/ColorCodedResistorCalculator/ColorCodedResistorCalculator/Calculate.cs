﻿using System;
using System.Windows.Forms;
using ColorCodedResistorCalculator.DataModel;

namespace ColorCodedResistorCalculator
{
    public class Calculate 
    {
        protected Button calculate;
        protected char band;
        protected const char three_band = '3', four_band = '4', five_band = '5', six_band = '6';

        public Calculate(Button calculate)
        {
            this.calculate = calculate;
            calculate.Enabled = false;
        }
        //Identifies the color-code value of the resistor then calculates
        public Result CalculateBand(Panel[] resistor_colors) 
        {
            Result result = new Result(-1, -1, -1, -1, -1);
            Panel first_digit_color = resistor_colors[0], second_digit_color = resistor_colors[1],
                third_digit_color, multiplier_color, tolerance_color, temp_coefficient_color;
            
            switch (band)
            {
                case three_band:
                    multiplier_color = resistor_colors[2];
                    result = CalculateSelectedBand(first_digit_color, second_digit_color, multiplier_color);
                    break;
                case four_band:
                    multiplier_color = resistor_colors[2];
                    tolerance_color = resistor_colors[3];
                    result = CalculateSelectedBand(first_digit_color, second_digit_color, multiplier_color, tolerance_color);
                    break;
                case five_band:
                    third_digit_color = resistor_colors[2];
                    multiplier_color = resistor_colors[3];
                    tolerance_color = resistor_colors[4];
                    result = CalculateSelectedBand(first_digit_color, second_digit_color, third_digit_color, multiplier_color, tolerance_color);
                    break;
                case six_band:
                    third_digit_color = resistor_colors[2];
                    multiplier_color = resistor_colors[3];
                    tolerance_color = resistor_colors[4];
                    temp_coefficient_color = resistor_colors[5];
                    result = CalculateSelectedBand(first_digit_color, second_digit_color, third_digit_color, multiplier_color, tolerance_color, temp_coefficient_color);
                    break;
            }
            return result;
        }

        #region Calculates the resistor's different bands
        private Result CalculateSelectedBand(Panel c1, Panel c2, Panel c3) //CalculateBand (for 3-band resistor)
        {
            string concat_digits = string.Concat(GetColorValue(c1).Digit, GetColorValue(c2).Digit);
            int digits = Convert.ToInt32(concat_digits);
            double resistance = digits * GetColorValue(c3).Multiplier;

            double min_resistance = GetMinMaxResistance(resistance).Min;
            double max_resistance = GetMinMaxResistance(resistance).Max;
            double tolerance = 20; // The default tolerance value of 3-band resistor is 20%
            Result result = new Result(resistance, tolerance, min_resistance, max_resistance, -1);
            return result;
        }
        private Result CalculateSelectedBand(Panel c1, Panel c2, Panel c3, Panel c4) //CalculateBand (for 4-band resistor)
        {
            string concat_digits = string.Concat(GetColorValue(c1).Digit, GetColorValue(c2).Digit);
            int digits = Convert.ToInt32(concat_digits);                                         
            double resistance = digits * GetColorValue(c3).Multiplier;
                    
            double min_resistance = GetMinMaxResistance(c4,resistance).Min;
            double max_resistance = GetMinMaxResistance(c4, resistance).Max;
            double tolerance = GetColorValue(c4).Tolerance;
            Result result = new Result(resistance, tolerance, min_resistance, max_resistance, -1);
            return result;
        }

        private Result CalculateSelectedBand(Panel c1, Panel c2, Panel c3, Panel c4, Panel c5) //CalculateBand (for 5-band resistor)
        {
            string concat_digits = string.Concat(GetColorValue(c1).Digit, GetColorValue(c2).Digit, GetColorValue(c3).Digit);
            int digits = Convert.ToInt32(concat_digits);
            double resistance = digits * GetColorValue(c4).Multiplier;

            double min_resistance = GetMinMaxResistance(c5, resistance).Min;
            double max_resistance = GetMinMaxResistance(c5, resistance).Max;
            double tolerance = GetColorValue(c5).Tolerance;
            Result result = new Result(resistance, tolerance, min_resistance, max_resistance, -1);
            return result;
        }

        private Result CalculateSelectedBand(Panel c1, Panel c2, Panel c3, Panel c4, Panel c5, Panel c6) //CalculateBand (for 6-band resistor)
        {
            string concat_digits = string.Concat(GetColorValue(c1).Digit, GetColorValue(c2).Digit, GetColorValue(c3).Digit);
            int digits = Convert.ToInt32(concat_digits);
            double resistance = digits * GetColorValue(c4).Multiplier;

            double min_resistance = GetMinMaxResistance(c5, resistance).Min;
            double max_resistance = GetMinMaxResistance(c5, resistance).Max;
            double tolerance = GetColorValue(c5).Tolerance;

            int temp_coefficient = GetColorValue(c6).Temp_Coefficient;
            Result result = new Result(resistance, tolerance, min_resistance, max_resistance, temp_coefficient);
            return result;
        }


        private MinMaxResistance GetMinMaxResistance(Panel tolerance_color_panel, double resistance)
        {
            double tolerance = GetColorValue(tolerance_color_panel).Tolerance;
            // Formula: tolerance = (tolerance value / 100) x resistance 
            tolerance /= 100; 
            tolerance *= resistance; 
            double minResistance = resistance - tolerance;
            double maxResistance = resistance + tolerance;

            MinMaxResistance minMaxResistance = new MinMaxResistance(minResistance, maxResistance);
            return minMaxResistance;
        }

        private MinMaxResistance GetMinMaxResistance(double resistance) // For 3 band only that has a default tolerance value of 20%
        {
            double tolerance = 20; // default tolerance value of 3 band resistor

            tolerance /= 100; 
            tolerance *= resistance; 

            double minResistance = resistance - tolerance;
            double maxResistance = resistance + tolerance;
            MinMaxResistance result = new MinMaxResistance(minResistance, maxResistance);
            return result;
        }

        #endregion
        #region Assigning the values in every resistor's color
        private ColorValue GetColorValue(Panel color)
        {
            ColorValue black = new ColorValue(0, 1, -1, 250);
            ColorValue brown = new ColorValue(1, 10, 1, 100);
            ColorValue red = new ColorValue(2, 100, 2, 50);
            ColorValue orange = new ColorValue(3, 1000, 3, 15);
            ColorValue yellow = new ColorValue(4, 10_000, 4, 25);
            ColorValue green = new ColorValue(5, 100_000, 0.5, 20);
            ColorValue blue = new ColorValue(6, 1000_000, 0.25, 10);
            ColorValue violet = new ColorValue(7, 10_000_000, 0.10, 5);
            ColorValue gray = new ColorValue(8, 100_000_000, 0.05, 1);
            ColorValue white = new ColorValue(9, 1000_000_000, -1, -1);
            ColorValue gold = new ColorValue(-1, 0.1, 5, -1);
            ColorValue silver = new ColorValue(-1, 0.01, 10, -1);

            ColorValue colorValues;
            switch (color.BackColor.Name)
            {
                case "Black": colorValues = black; break;
                case "Brown": colorValues = brown; break;
                case "Red": colorValues = red; break;
                case "Orange":colorValues = orange; break;
                case "Yellow": colorValues = yellow; break;
                case "Green": colorValues = green; break;
                case "Blue": colorValues = blue; break;
                case "Violet": colorValues = violet; break;
                case "Gray": colorValues = gray; break;
                case "White": colorValues = white; break;
                case "Gold": colorValues = gold; break;
                case "Silver": colorValues = silver; break;
                default: colorValues = new ColorValue(-1, -1, -1, -1); break;
            }   
            return colorValues;
        }
        #endregion
    }
}
