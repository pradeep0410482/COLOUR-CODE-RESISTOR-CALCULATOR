﻿using System;
using System.Windows.Forms;
using ColorCodedResistorCalculator.DataModel;

namespace ColorCodedResistorCalculator
{
    public partial class Form1 : Form
    {

        Panel[][] allPanelBands;
        Button[] coloredButtons;
        PictureBox[] selectionGuideImages;
        Panel[] _3BandPanels, _4BandPanels, _5BandPanels, _6BandPanels;
        const char three = '3', four = '4', five = '5', six = '6';
        char band;
        ColorControl colorControl;
        
        public Form1()
        {
            InitializeComponent();
            InitializeColorControl();
        }

        private void InitializeColorControl()
        {
            _3BandPanels = new Panel[] { ThreeBandPanel1, ThreeBandPanel2, ThreeBandPanel3 };
            _4BandPanels = new Panel[] { FourBandPanel1, FourBandPanel2, FourBandPanel3, FourBandPanel4 };
            _5BandPanels = new Panel[] { FiveBandPanel1, FiveBandPanel2, FiveBandPanel3, FiveBandPanel4, FiveBandPanel5 };
            _6BandPanels = new Panel[] { SixBandPanel1, SixBandPanel2, SixBandPanel3, SixBandPanel4, SixBandPanel5, SixBandPanel6 };

            allPanelBands = new Panel[][] { _3BandPanels, _4BandPanels, _5BandPanels, _6BandPanels };

            selectionGuideImages = new PictureBox[] { _1stDigitImg, _2ndDigitImg, _3rdDigitImg, MultiplierImg, ToleranceImg, TempCoefficientImg };
            coloredButtons = new Button[] { Black, Brown, Red, Orange, Yellow, Green, Blue, Violet, Gray, White, Gold, Silver };
            colorControl = new ColorControl(coloredButtons, selectionGuideImages, SelectionGuideLbl, CalculateBtn, UndoBtn, allPanelBands, selectedColorsTxt);
        }
       
        private void UndoBtn_Click(object sender, EventArgs e)
        {
            UndoColorFromSelectedBand();
        }

        private void CalculateBtn_Click(object sender, EventArgs e)
        {
            DisplayCalculation();
        }

        #region Colored Buttons' Click Events (For Selecting Colors)
        private void Gold_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Gold);
        }

        private void Silver_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Silver);
        }

        private void Brown_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Brown);
        }

        private void Red_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Red);
        }

        private void Orange_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Orange);
        }

        private void Yellow_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Yellow);
        }

        private void Green_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Green);
        }

        private void Blue_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Blue);
        }

        private void Violet_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Violet);
        }

        private void Gray_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Gray);
        }

        private void White_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(White);
        }

        private void Black_Click(object sender, EventArgs e)
        {
            AddColorToSelectedBand(Black);
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            colorControl.Reset(band);
            ClearCalculation();
        }

        #endregion

        #region RadioButtons CheckChanged events (Selection of Resistor Band)

        private void _6BandBtn_CheckedChanged(object sender, EventArgs e)
        {
            band = six;
            colorControl.Reset(band);
            ClearCalculation();
        }

        private void _5BandBtn_CheckedChanged(object sender, EventArgs e)
        {
            band = five;
            colorControl.Reset(band);
            ClearCalculation();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            login obj = new login();
            obj.ShowDialog();
        }

        private void _4BandBtn_CheckedChanged(object sender, EventArgs e)
        {
            band = four;
            colorControl.Reset(band);
            ClearCalculation();
        }

        private void _3BandBtn_CheckedChanged(object sender, EventArgs e)
        {
            band = three;
            colorControl.Reset(band);
            ClearCalculation();
        }
        #endregion

        #region Other methods
        private void DisplayCalculation()
        {
            Result result;

            switch (band)
            {
                case three: DisplayCalculation(_3BandPanels); break;
                case four: DisplayCalculation(_4BandPanels); break;
                case five: DisplayCalculation(_5BandPanels); break;
                case six:
                    DisplayCalculation(_6BandPanels);
                    TempCoefficientTxt.Text = $"{result.Temp_Coefficient.ToString()} ppm/°C";
                    break;
            }

            void DisplayCalculation(Panel[] colorBand)
            {
                result = colorControl.CalculateBand(colorBand);

                double resistance = result.Resistance;
                string resistanceTxt = $"{FormatToScaleOfNumber(resistance)} ±{result.Tolerance}%";
                ResistanceTxt.Text = resistanceTxt;

                double minResistance = result.MinResistance;
                string minResistanceTxt = FormatToScaleOfNumber(minResistance);
                MinResistanceTxt.Text = minResistanceTxt;

                double maxResistance = result.MaxResistance;
                string maxResistanceTxt = FormatToScaleOfNumber(maxResistance);
                MaxResistanceTxt.Text = maxResistanceTxt;
            }

            string FormatToScaleOfNumber(double resistance)
            {
                double kilo = 1000;
                double mega = 1000_000;
                double giga = 1000_000_000;
                double tera = 1000_000_000_000;
                double exceed = 10_000_000_000_000;

                bool IsKiloOhm = resistance >= kilo && resistance < mega;
                bool IsMegaOhm = resistance >= mega && resistance < giga;
                bool IsGigaOhm = resistance >= giga && resistance < tera;
                bool IsTeraOhm = resistance >= tera && resistance < exceed;

                // Below is the Ternary Conditional Operator this is like an if else statement but it shortens my code, if you don't know this, you can read this in C# documentation of microsoft
                string customNumFormat = "#.###";// This is a custom numeric format that formats the value of numbers
                string str = IsKiloOhm ? $"{(resistance / kilo).ToString(customNumFormat)} kΩ" :
                      IsMegaOhm ? $"{(resistance / mega).ToString(customNumFormat)} MΩ" :
                      IsGigaOhm ? $"{(resistance / giga).ToString(customNumFormat)} GΩ" :
                      IsTeraOhm ? $"{(resistance / tera).ToString(customNumFormat)} TΩ" :
                      resistance + "Ω";
                return str;
            }
        }

        private void ClearCalculation()
        {
            if(!string.IsNullOrWhiteSpace(ResistanceTxt.Text))
            {
                ResistanceTxt.Text = string.Empty;
                MinResistanceTxt.Text = string.Empty;
                MaxResistanceTxt.Text = string.Empty;
                TempCoefficientTxt.Text = string.Empty;
            }
        }

        private void AddColorToSelectedBand(Button btn)
        {
            switch (band)
            {
                case three: colorControl.AddColor(btn.BackColor, _3BandPanels, three); break;
                case four: colorControl.AddColor(btn.BackColor, _4BandPanels, four); break;
                case five: colorControl.AddColor(btn.BackColor, _5BandPanels, five); break;
                case six: colorControl.AddColor(btn.BackColor, _6BandPanels, six); break;
            }
        }

        private void UndoColorFromSelectedBand()
        {
            switch (band)
            {
                case three: colorControl.UndoColor(_3BandPanels, three); break;
                case four: colorControl.UndoColor(_4BandPanels, four); break;
                case five: colorControl.UndoColor(_5BandPanels, five); break;
                case six: colorControl.UndoColor(_6BandPanels, six); break;
            }
            ClearCalculation();
        }
        #endregion
    }


}
