﻿namespace ColorCodedResistorCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.FourBandPanel1 = new System.Windows.Forms.Panel();
            this.FourBandPanel2 = new System.Windows.Forms.Panel();
            this.FourBandPanel3 = new System.Windows.Forms.Panel();
            this.FourBandPanel4 = new System.Windows.Forms.Panel();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.ResistanceTxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.FiveBandPanel1 = new System.Windows.Forms.Panel();
            this.FiveBandPanel5 = new System.Windows.Forms.Panel();
            this.FiveBandPanel4 = new System.Windows.Forms.Panel();
            this.FiveBandPanel2 = new System.Windows.Forms.Panel();
            this.FiveBandPanel3 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TempCoefficientImg = new System.Windows.Forms.PictureBox();
            this.ToleranceImg = new System.Windows.Forms.PictureBox();
            this.MultiplierImg = new System.Windows.Forms.PictureBox();
            this._3rdDigitImg = new System.Windows.Forms.PictureBox();
            this._2ndDigitImg = new System.Windows.Forms.PictureBox();
            this._1stDigitImg = new System.Windows.Forms.PictureBox();
            this.TemperatureCoefficient = new System.Windows.Forms.TableLayoutPanel();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.Tolerance = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.Multiplier = new System.Windows.Forms.TableLayoutPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.ThirdDigit = new System.Windows.Forms.TableLayoutPanel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.SecondDigit = new System.Windows.Forms.TableLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.SelectionGuideLbl = new System.Windows.Forms.Label();
            this.FirstDigit = new System.Windows.Forms.TableLayoutPanel();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.Silver = new System.Windows.Forms.Button();
            this.Gold = new System.Windows.Forms.Button();
            this.White = new System.Windows.Forms.Button();
            this.Gray = new System.Windows.Forms.Button();
            this.Violet = new System.Windows.Forms.Button();
            this.Blue = new System.Windows.Forms.Button();
            this.Green = new System.Windows.Forms.Button();
            this.Yellow = new System.Windows.Forms.Button();
            this.Orange = new System.Windows.Forms.Button();
            this.Red = new System.Windows.Forms.Button();
            this.Brown = new System.Windows.Forms.Button();
            this.Black = new System.Windows.Forms.Button();
            this.selectedColorsTxt = new System.Windows.Forms.TextBox();
            this.UndoBtn = new System.Windows.Forms.Button();
            this.SixBandPanel3 = new System.Windows.Forms.Panel();
            this.SixBandPanel5 = new System.Windows.Forms.Panel();
            this.SixBandPanel6 = new System.Windows.Forms.Panel();
            this.SixBandPanel1 = new System.Windows.Forms.Panel();
            this.SixBandPanel4 = new System.Windows.Forms.Panel();
            this.SixBandPanel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.MinResistanceTxt = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.MaxResistanceTxt = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.TempCoefficientTxt = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ThreeBandPanel3 = new System.Windows.Forms.Panel();
            this.ThreeBandPanel1 = new System.Windows.Forms.Panel();
            this.ThreeBandPanel2 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this._6BandBtn = new System.Windows.Forms.RadioButton();
            this._3BandBtn = new System.Windows.Forms.RadioButton();
            this._5BandBtn = new System.Windows.Forms.RadioButton();
            this._4BandBtn = new System.Windows.Forms.RadioButton();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TempCoefficientImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToleranceImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MultiplierImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._3rdDigitImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._2ndDigitImg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._1stDigitImg)).BeginInit();
            this.TemperatureCoefficient.SuspendLayout();
            this.Tolerance.SuspendLayout();
            this.Multiplier.SuspendLayout();
            this.ThirdDigit.SuspendLayout();
            this.SecondDigit.SuspendLayout();
            this.FirstDigit.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // FourBandPanel1
            // 
            this.FourBandPanel1.Location = new System.Drawing.Point(20, 0);
            this.FourBandPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FourBandPanel1.Name = "FourBandPanel1";
            this.FourBandPanel1.Size = new System.Drawing.Size(13, 63);
            this.FourBandPanel1.TabIndex = 8;
            // 
            // FourBandPanel2
            // 
            this.FourBandPanel2.Location = new System.Drawing.Point(47, 0);
            this.FourBandPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FourBandPanel2.Name = "FourBandPanel2";
            this.FourBandPanel2.Size = new System.Drawing.Size(13, 63);
            this.FourBandPanel2.TabIndex = 9;
            // 
            // FourBandPanel3
            // 
            this.FourBandPanel3.Location = new System.Drawing.Point(73, 0);
            this.FourBandPanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FourBandPanel3.Name = "FourBandPanel3";
            this.FourBandPanel3.Size = new System.Drawing.Size(13, 63);
            this.FourBandPanel3.TabIndex = 9;
            // 
            // FourBandPanel4
            // 
            this.FourBandPanel4.Location = new System.Drawing.Point(100, 0);
            this.FourBandPanel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FourBandPanel4.Name = "FourBandPanel4";
            this.FourBandPanel4.Size = new System.Drawing.Size(13, 63);
            this.FourBandPanel4.TabIndex = 9;
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.ForeColor = System.Drawing.Color.Black;
            this.CalculateBtn.Location = new System.Drawing.Point(15, 126);
            this.CalculateBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(100, 46);
            this.CalculateBtn.TabIndex = 12;
            this.CalculateBtn.Text = "Calculate";
            this.CalculateBtn.UseVisualStyleBackColor = true;
            this.CalculateBtn.Click += new System.EventHandler(this.CalculateBtn_Click);
            // 
            // ResistanceTxt
            // 
            this.ResistanceTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ResistanceTxt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResistanceTxt.Location = new System.Drawing.Point(192, 25);
            this.ResistanceTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ResistanceTxt.Name = "ResistanceTxt";
            this.ResistanceTxt.ReadOnly = true;
            this.ResistanceTxt.Size = new System.Drawing.Size(227, 24);
            this.ResistanceTxt.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(87, 28);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Resistance:";
            // 
            // FiveBandPanel1
            // 
            this.FiveBandPanel1.Location = new System.Drawing.Point(16, 0);
            this.FiveBandPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FiveBandPanel1.Name = "FiveBandPanel1";
            this.FiveBandPanel1.Size = new System.Drawing.Size(13, 63);
            this.FiveBandPanel1.TabIndex = 22;
            // 
            // FiveBandPanel5
            // 
            this.FiveBandPanel5.Location = new System.Drawing.Point(109, 0);
            this.FiveBandPanel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FiveBandPanel5.Name = "FiveBandPanel5";
            this.FiveBandPanel5.Size = new System.Drawing.Size(13, 63);
            this.FiveBandPanel5.TabIndex = 23;
            // 
            // FiveBandPanel4
            // 
            this.FiveBandPanel4.Location = new System.Drawing.Point(85, 0);
            this.FiveBandPanel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FiveBandPanel4.Name = "FiveBandPanel4";
            this.FiveBandPanel4.Size = new System.Drawing.Size(13, 63);
            this.FiveBandPanel4.TabIndex = 24;
            // 
            // FiveBandPanel2
            // 
            this.FiveBandPanel2.Location = new System.Drawing.Point(39, 0);
            this.FiveBandPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FiveBandPanel2.Name = "FiveBandPanel2";
            this.FiveBandPanel2.Size = new System.Drawing.Size(13, 63);
            this.FiveBandPanel2.TabIndex = 25;
            // 
            // FiveBandPanel3
            // 
            this.FiveBandPanel3.Location = new System.Drawing.Point(63, 0);
            this.FiveBandPanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FiveBandPanel3.Name = "FiveBandPanel3";
            this.FiveBandPanel3.Size = new System.Drawing.Size(13, 63);
            this.FiveBandPanel3.TabIndex = 28;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TempCoefficientImg);
            this.groupBox2.Controls.Add(this.ToleranceImg);
            this.groupBox2.Controls.Add(this.MultiplierImg);
            this.groupBox2.Controls.Add(this._3rdDigitImg);
            this.groupBox2.Controls.Add(this._2ndDigitImg);
            this.groupBox2.Controls.Add(this._1stDigitImg);
            this.groupBox2.Controls.Add(this.TemperatureCoefficient);
            this.groupBox2.Controls.Add(this.Tolerance);
            this.groupBox2.Controls.Add(this.Multiplier);
            this.groupBox2.Controls.Add(this.ThirdDigit);
            this.groupBox2.Controls.Add(this.SecondDigit);
            this.groupBox2.Controls.Add(this.SelectionGuideLbl);
            this.groupBox2.Controls.Add(this.FirstDigit);
            this.groupBox2.Controls.Add(this.tableLayoutPanel7);
            this.groupBox2.Location = new System.Drawing.Point(27, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(579, 587);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pick a Color";
            // 
            // TempCoefficientImg
            // 
            this.TempCoefficientImg.Image = ((System.Drawing.Image)(resources.GetObject("TempCoefficientImg.Image")));
            this.TempCoefficientImg.Location = new System.Drawing.Point(501, 63);
            this.TempCoefficientImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TempCoefficientImg.Name = "TempCoefficientImg";
            this.TempCoefficientImg.Size = new System.Drawing.Size(21, 20);
            this.TempCoefficientImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.TempCoefficientImg.TabIndex = 54;
            this.TempCoefficientImg.TabStop = false;
            this.TempCoefficientImg.Visible = false;
            // 
            // ToleranceImg
            // 
            this.ToleranceImg.Image = ((System.Drawing.Image)(resources.GetObject("ToleranceImg.Image")));
            this.ToleranceImg.Location = new System.Drawing.Point(441, 63);
            this.ToleranceImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ToleranceImg.Name = "ToleranceImg";
            this.ToleranceImg.Size = new System.Drawing.Size(21, 20);
            this.ToleranceImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.ToleranceImg.TabIndex = 53;
            this.ToleranceImg.TabStop = false;
            this.ToleranceImg.Visible = false;
            // 
            // MultiplierImg
            // 
            this.MultiplierImg.Image = ((System.Drawing.Image)(resources.GetObject("MultiplierImg.Image")));
            this.MultiplierImg.Location = new System.Drawing.Point(383, 63);
            this.MultiplierImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MultiplierImg.Name = "MultiplierImg";
            this.MultiplierImg.Size = new System.Drawing.Size(21, 20);
            this.MultiplierImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.MultiplierImg.TabIndex = 52;
            this.MultiplierImg.TabStop = false;
            this.MultiplierImg.Visible = false;
            // 
            // _3rdDigitImg
            // 
            this._3rdDigitImg.Image = ((System.Drawing.Image)(resources.GetObject("_3rdDigitImg.Image")));
            this._3rdDigitImg.Location = new System.Drawing.Point(324, 63);
            this._3rdDigitImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._3rdDigitImg.Name = "_3rdDigitImg";
            this._3rdDigitImg.Size = new System.Drawing.Size(21, 20);
            this._3rdDigitImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this._3rdDigitImg.TabIndex = 51;
            this._3rdDigitImg.TabStop = false;
            this._3rdDigitImg.Visible = false;
            // 
            // _2ndDigitImg
            // 
            this._2ndDigitImg.Image = ((System.Drawing.Image)(resources.GetObject("_2ndDigitImg.Image")));
            this._2ndDigitImg.Location = new System.Drawing.Point(265, 63);
            this._2ndDigitImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._2ndDigitImg.Name = "_2ndDigitImg";
            this._2ndDigitImg.Size = new System.Drawing.Size(21, 20);
            this._2ndDigitImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this._2ndDigitImg.TabIndex = 50;
            this._2ndDigitImg.TabStop = false;
            this._2ndDigitImg.Visible = false;
            // 
            // _1stDigitImg
            // 
            this._1stDigitImg.Image = ((System.Drawing.Image)(resources.GetObject("_1stDigitImg.Image")));
            this._1stDigitImg.Location = new System.Drawing.Point(208, 63);
            this._1stDigitImg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._1stDigitImg.Name = "_1stDigitImg";
            this._1stDigitImg.Size = new System.Drawing.Size(21, 20);
            this._1stDigitImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this._1stDigitImg.TabIndex = 49;
            this._1stDigitImg.TabStop = false;
            this._1stDigitImg.Visible = false;
            // 
            // TemperatureCoefficient
            // 
            this.TemperatureCoefficient.ColumnCount = 1;
            this.TemperatureCoefficient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TemperatureCoefficient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.TemperatureCoefficient.Controls.Add(this.label57, 0, 8);
            this.TemperatureCoefficient.Controls.Add(this.label56, 0, 5);
            this.TemperatureCoefficient.Controls.Add(this.label55, 0, 0);
            this.TemperatureCoefficient.Controls.Add(this.label10, 0, 7);
            this.TemperatureCoefficient.Controls.Add(this.label65, 0, 1);
            this.TemperatureCoefficient.Controls.Add(this.label9, 0, 6);
            this.TemperatureCoefficient.Controls.Add(this.label66, 0, 2);
            this.TemperatureCoefficient.Controls.Add(this.label67, 0, 3);
            this.TemperatureCoefficient.Controls.Add(this.label68, 0, 4);
            this.TemperatureCoefficient.Location = new System.Drawing.Point(480, 95);
            this.TemperatureCoefficient.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TemperatureCoefficient.Name = "TemperatureCoefficient";
            this.TemperatureCoefficient.RowCount = 12;
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.TemperatureCoefficient.Size = new System.Drawing.Size(60, 462);
            this.TemperatureCoefficient.TabIndex = 36;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Gray;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(4, 304);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(52, 38);
            this.label57.TabIndex = 55;
            this.label57.Text = "1ppm";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Green;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(4, 190);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(52, 38);
            this.label56.TabIndex = 55;
            this.label56.Text = "20ppm";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Black;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(4, 0);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(52, 38);
            this.label55.TabIndex = 55;
            this.label55.Text = "250ppm";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Violet;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(4, 266);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 38);
            this.label10.TabIndex = 56;
            this.label10.Text = "5ppm";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.Color.Brown;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.White;
            this.label65.Location = new System.Drawing.Point(4, 38);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(52, 38);
            this.label65.TabIndex = 6;
            this.label65.Text = "100ppm";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Blue;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(4, 228);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 38);
            this.label9.TabIndex = 56;
            this.label9.Text = "10ppm";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.Color.Red;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.White;
            this.label66.Location = new System.Drawing.Point(4, 76);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(52, 38);
            this.label66.TabIndex = 7;
            this.label66.Text = "50ppm";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.Color.Orange;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.White;
            this.label67.Location = new System.Drawing.Point(4, 114);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(52, 38);
            this.label67.TabIndex = 8;
            this.label67.Text = "15ppm";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.Yellow;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(4, 152);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(52, 38);
            this.label68.TabIndex = 9;
            this.label68.Text = "25ppm";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tolerance
            // 
            this.Tolerance.ColumnCount = 1;
            this.Tolerance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tolerance.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.Tolerance.Controls.Add(this.label8, 0, 4);
            this.Tolerance.Controls.Add(this.label7, 0, 3);
            this.Tolerance.Controls.Add(this.label11, 0, 1);
            this.Tolerance.Controls.Add(this.label71, 0, 11);
            this.Tolerance.Controls.Add(this.label72, 0, 10);
            this.Tolerance.Controls.Add(this.label74, 0, 8);
            this.Tolerance.Controls.Add(this.label75, 0, 7);
            this.Tolerance.Controls.Add(this.label78, 0, 2);
            this.Tolerance.Controls.Add(this.label81, 0, 5);
            this.Tolerance.Controls.Add(this.label82, 0, 6);
            this.Tolerance.Location = new System.Drawing.Point(421, 95);
            this.Tolerance.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Tolerance.Name = "Tolerance";
            this.Tolerance.RowCount = 12;
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Tolerance.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.Tolerance.Size = new System.Drawing.Size(60, 462);
            this.Tolerance.TabIndex = 35;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Yellow;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(4, 152);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 38);
            this.label8.TabIndex = 65;
            this.label8.Text = "±4%";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Orange;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(4, 114);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 38);
            this.label7.TabIndex = 65;
            this.label7.Text = "±3%";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Brown;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(4, 38);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 38);
            this.label11.TabIndex = 46;
            this.label11.Text = "±1% (F)";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Silver;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.White;
            this.label71.Location = new System.Drawing.Point(4, 418);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(52, 44);
            this.label71.TabIndex = 45;
            this.label71.Text = "10%";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.Gold;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.White;
            this.label72.Location = new System.Drawing.Point(4, 380);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(52, 38);
            this.label72.TabIndex = 44;
            this.label72.Text = "5%";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.BackColor = System.Drawing.Color.Gray;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.White;
            this.label74.Location = new System.Drawing.Point(4, 304);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(52, 38);
            this.label74.TabIndex = 43;
            this.label74.Text = "0.05% (A)";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.BackColor = System.Drawing.Color.Violet;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(4, 266);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(52, 38);
            this.label75.TabIndex = 43;
            this.label75.Text = "0.10% (B)";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.BackColor = System.Drawing.Color.Red;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.Color.White;
            this.label78.Location = new System.Drawing.Point(4, 76);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(52, 38);
            this.label78.TabIndex = 7;
            this.label78.Text = "±2% (G)";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.BackColor = System.Drawing.Color.Green;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.Color.White;
            this.label81.Location = new System.Drawing.Point(4, 190);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(52, 38);
            this.label81.TabIndex = 10;
            this.label81.Text = "0.5% (D)";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.Blue;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.White;
            this.label82.Location = new System.Drawing.Point(4, 228);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(52, 38);
            this.label82.TabIndex = 12;
            this.label82.Text = "0.25% (C)";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Multiplier
            // 
            this.Multiplier.ColumnCount = 1;
            this.Multiplier.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Multiplier.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.Multiplier.Controls.Add(this.label6, 0, 9);
            this.Multiplier.Controls.Add(this.label4, 0, 8);
            this.Multiplier.Controls.Add(this.label23, 0, 11);
            this.Multiplier.Controls.Add(this.label24, 0, 10);
            this.Multiplier.Controls.Add(this.label27, 0, 7);
            this.Multiplier.Controls.Add(this.label28, 0, 0);
            this.Multiplier.Controls.Add(this.label29, 0, 1);
            this.Multiplier.Controls.Add(this.label30, 0, 2);
            this.Multiplier.Controls.Add(this.label31, 0, 3);
            this.Multiplier.Controls.Add(this.label32, 0, 4);
            this.Multiplier.Controls.Add(this.label33, 0, 5);
            this.Multiplier.Controls.Add(this.label34, 0, 6);
            this.Multiplier.Location = new System.Drawing.Point(363, 95);
            this.Multiplier.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Multiplier.Name = "Multiplier";
            this.Multiplier.RowCount = 12;
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.Multiplier.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.Multiplier.Size = new System.Drawing.Size(60, 462);
            this.Multiplier.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(4, 342);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 38);
            this.label6.TabIndex = 56;
            this.label6.Text = "1GΩ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Gray;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(4, 304);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 38);
            this.label4.TabIndex = 65;
            this.label4.Text = "100MΩ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Silver;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(4, 418);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 44);
            this.label23.TabIndex = 45;
            this.label23.Text = "0.01";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Gold;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(4, 380);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(52, 38);
            this.label24.TabIndex = 44;
            this.label24.Text = "0.1";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Violet;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(4, 266);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 38);
            this.label27.TabIndex = 43;
            this.label27.Text = "10MΩ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Black;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(4, 0);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(52, 38);
            this.label28.TabIndex = 5;
            this.label28.Text = "1Ω";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Brown;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(4, 38);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(52, 38);
            this.label29.TabIndex = 6;
            this.label29.Text = "10Ω";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Red;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(4, 76);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(52, 38);
            this.label30.TabIndex = 7;
            this.label30.Text = "100Ω";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Orange;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(4, 114);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 38);
            this.label31.TabIndex = 8;
            this.label31.Text = "1KΩ";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Yellow;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(4, 152);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 38);
            this.label32.TabIndex = 9;
            this.label32.Text = "10KΩ";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Green;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(4, 190);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 38);
            this.label33.TabIndex = 10;
            this.label33.Text = "100KΩ";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Blue;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(4, 228);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(52, 38);
            this.label34.TabIndex = 12;
            this.label34.Text = "1MΩ";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ThirdDigit
            // 
            this.ThirdDigit.ColumnCount = 1;
            this.ThirdDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.ThirdDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.ThirdDigit.Controls.Add(this.label39, 0, 9);
            this.ThirdDigit.Controls.Add(this.label40, 0, 8);
            this.ThirdDigit.Controls.Add(this.label42, 0, 7);
            this.ThirdDigit.Controls.Add(this.label43, 0, 0);
            this.ThirdDigit.Controls.Add(this.label48, 0, 1);
            this.ThirdDigit.Controls.Add(this.label50, 0, 2);
            this.ThirdDigit.Controls.Add(this.label51, 0, 3);
            this.ThirdDigit.Controls.Add(this.label52, 0, 4);
            this.ThirdDigit.Controls.Add(this.label53, 0, 5);
            this.ThirdDigit.Controls.Add(this.label54, 0, 6);
            this.ThirdDigit.Location = new System.Drawing.Point(304, 95);
            this.ThirdDigit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ThirdDigit.Name = "ThirdDigit";
            this.ThirdDigit.RowCount = 12;
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.ThirdDigit.Size = new System.Drawing.Size(60, 462);
            this.ThirdDigit.TabIndex = 33;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.White;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(4, 342);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(52, 38);
            this.label39.TabIndex = 43;
            this.label39.Text = "9";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Gray;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(4, 304);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(52, 38);
            this.label40.TabIndex = 43;
            this.label40.Text = "8";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Violet;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(4, 266);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(52, 38);
            this.label42.TabIndex = 43;
            this.label42.Text = "7";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Black;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(4, 0);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 38);
            this.label43.TabIndex = 5;
            this.label43.Text = "0";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Brown;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(4, 38);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(52, 38);
            this.label48.TabIndex = 6;
            this.label48.Text = "1";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Red;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(4, 76);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(52, 38);
            this.label50.TabIndex = 7;
            this.label50.Text = "2";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Orange;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(4, 114);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(52, 38);
            this.label51.TabIndex = 8;
            this.label51.Text = "3";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Yellow;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(4, 152);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(52, 38);
            this.label52.TabIndex = 9;
            this.label52.Text = "4";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Green;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(4, 190);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(52, 38);
            this.label53.TabIndex = 10;
            this.label53.Text = "5";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Blue;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(4, 228);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(52, 38);
            this.label54.TabIndex = 12;
            this.label54.Text = "6";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SecondDigit
            // 
            this.SecondDigit.ColumnCount = 1;
            this.SecondDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.SecondDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.SecondDigit.Controls.Add(this.label13, 0, 9);
            this.SecondDigit.Controls.Add(this.label14, 0, 8);
            this.SecondDigit.Controls.Add(this.label15, 0, 7);
            this.SecondDigit.Controls.Add(this.label16, 0, 0);
            this.SecondDigit.Controls.Add(this.label17, 0, 1);
            this.SecondDigit.Controls.Add(this.label18, 0, 2);
            this.SecondDigit.Controls.Add(this.label19, 0, 3);
            this.SecondDigit.Controls.Add(this.label20, 0, 4);
            this.SecondDigit.Controls.Add(this.label21, 0, 5);
            this.SecondDigit.Controls.Add(this.label22, 0, 6);
            this.SecondDigit.Location = new System.Drawing.Point(244, 95);
            this.SecondDigit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SecondDigit.Name = "SecondDigit";
            this.SecondDigit.RowCount = 12;
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.SecondDigit.Size = new System.Drawing.Size(60, 462);
            this.SecondDigit.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(4, 342);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 38);
            this.label13.TabIndex = 43;
            this.label13.Text = "9";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Gray;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(4, 304);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 38);
            this.label14.TabIndex = 43;
            this.label14.Text = "8";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Violet;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(4, 266);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 38);
            this.label15.TabIndex = 43;
            this.label15.Text = "7";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Black;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(4, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 38);
            this.label16.TabIndex = 5;
            this.label16.Text = "0";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Brown;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(4, 38);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 38);
            this.label17.TabIndex = 6;
            this.label17.Text = "1";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Red;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(4, 76);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 38);
            this.label18.TabIndex = 7;
            this.label18.Text = "2";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Orange;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(4, 114);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 38);
            this.label19.TabIndex = 8;
            this.label19.Text = "3";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Yellow;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(4, 152);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 38);
            this.label20.TabIndex = 9;
            this.label20.Text = "4";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Green;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(4, 190);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 38);
            this.label21.TabIndex = 10;
            this.label21.Text = "5";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Blue;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(4, 228);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 38);
            this.label22.TabIndex = 12;
            this.label22.Text = "6";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SelectionGuideLbl
            // 
            this.SelectionGuideLbl.ForeColor = System.Drawing.Color.Black;
            this.SelectionGuideLbl.Location = new System.Drawing.Point(181, 33);
            this.SelectionGuideLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SelectionGuideLbl.Name = "SelectionGuideLbl";
            this.SelectionGuideLbl.Size = new System.Drawing.Size(344, 16);
            this.SelectionGuideLbl.TabIndex = 48;
            this.SelectionGuideLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FirstDigit
            // 
            this.FirstDigit.ColumnCount = 1;
            this.FirstDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.FirstDigit.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.FirstDigit.Controls.Add(this.label60, 0, 9);
            this.FirstDigit.Controls.Add(this.label59, 0, 8);
            this.FirstDigit.Controls.Add(this.label49, 0, 7);
            this.FirstDigit.Controls.Add(this.label36, 0, 0);
            this.FirstDigit.Controls.Add(this.label38, 0, 1);
            this.FirstDigit.Controls.Add(this.label41, 0, 2);
            this.FirstDigit.Controls.Add(this.label44, 0, 3);
            this.FirstDigit.Controls.Add(this.label45, 0, 4);
            this.FirstDigit.Controls.Add(this.label46, 0, 5);
            this.FirstDigit.Controls.Add(this.label47, 0, 6);
            this.FirstDigit.Location = new System.Drawing.Point(185, 95);
            this.FirstDigit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FirstDigit.Name = "FirstDigit";
            this.FirstDigit.RowCount = 12;
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.FirstDigit.Size = new System.Drawing.Size(60, 462);
            this.FirstDigit.TabIndex = 31;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.White;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(4, 342);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 38);
            this.label60.TabIndex = 43;
            this.label60.Text = "9";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Gray;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(4, 304);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(52, 38);
            this.label59.TabIndex = 43;
            this.label59.Text = "8";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Violet;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Black;
            this.label49.Location = new System.Drawing.Point(4, 266);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(52, 38);
            this.label49.TabIndex = 43;
            this.label49.Text = "7";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Black;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(4, 0);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(52, 38);
            this.label36.TabIndex = 5;
            this.label36.Text = "0";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Brown;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(4, 38);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(52, 38);
            this.label38.TabIndex = 6;
            this.label38.Text = "1";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Red;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(4, 76);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 38);
            this.label41.TabIndex = 7;
            this.label41.Text = "2";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Orange;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(4, 114);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(52, 38);
            this.label44.TabIndex = 8;
            this.label44.Text = "3";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Yellow;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(4, 152);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 38);
            this.label45.TabIndex = 9;
            this.label45.Text = "4";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Green;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(4, 190);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(52, 38);
            this.label46.TabIndex = 10;
            this.label46.Text = "5";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Blue;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(4, 228);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(52, 38);
            this.label47.TabIndex = 12;
            this.label47.Text = "6";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.Silver, 0, 11);
            this.tableLayoutPanel7.Controls.Add(this.Gold, 0, 10);
            this.tableLayoutPanel7.Controls.Add(this.White, 0, 9);
            this.tableLayoutPanel7.Controls.Add(this.Gray, 0, 8);
            this.tableLayoutPanel7.Controls.Add(this.Violet, 0, 7);
            this.tableLayoutPanel7.Controls.Add(this.Blue, 0, 6);
            this.tableLayoutPanel7.Controls.Add(this.Green, 0, 5);
            this.tableLayoutPanel7.Controls.Add(this.Yellow, 0, 4);
            this.tableLayoutPanel7.Controls.Add(this.Orange, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.Red, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.Brown, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.Black, 0, 0);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(41, 95);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 12;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(140, 462);
            this.tableLayoutPanel7.TabIndex = 38;
            // 
            // Silver
            // 
            this.Silver.BackColor = System.Drawing.Color.Silver;
            this.Silver.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Silver.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Silver.ForeColor = System.Drawing.Color.Black;
            this.Silver.Image = ((System.Drawing.Image)(resources.GetObject("Silver.Image")));
            this.Silver.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Silver.Location = new System.Drawing.Point(4, 422);
            this.Silver.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Silver.Name = "Silver";
            this.Silver.Size = new System.Drawing.Size(132, 36);
            this.Silver.TabIndex = 11;
            this.Silver.Text = "Silver";
            this.Silver.UseVisualStyleBackColor = false;
            this.Silver.Click += new System.EventHandler(this.Silver_Click);
            // 
            // Gold
            // 
            this.Gold.BackColor = System.Drawing.Color.Gold;
            this.Gold.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Gold.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gold.ForeColor = System.Drawing.Color.Black;
            this.Gold.Image = ((System.Drawing.Image)(resources.GetObject("Gold.Image")));
            this.Gold.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Gold.Location = new System.Drawing.Point(4, 384);
            this.Gold.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Gold.Name = "Gold";
            this.Gold.Size = new System.Drawing.Size(132, 30);
            this.Gold.TabIndex = 10;
            this.Gold.Text = "Gold";
            this.Gold.UseVisualStyleBackColor = false;
            this.Gold.Click += new System.EventHandler(this.Gold_Click);
            // 
            // White
            // 
            this.White.BackColor = System.Drawing.Color.White;
            this.White.Dock = System.Windows.Forms.DockStyle.Fill;
            this.White.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.White.ForeColor = System.Drawing.Color.Black;
            this.White.Image = ((System.Drawing.Image)(resources.GetObject("White.Image")));
            this.White.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.White.Location = new System.Drawing.Point(4, 346);
            this.White.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.White.Name = "White";
            this.White.Size = new System.Drawing.Size(132, 30);
            this.White.TabIndex = 9;
            this.White.Text = "White";
            this.White.UseVisualStyleBackColor = false;
            this.White.Click += new System.EventHandler(this.White_Click);
            // 
            // Gray
            // 
            this.Gray.BackColor = System.Drawing.Color.Gray;
            this.Gray.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Gray.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gray.Image = ((System.Drawing.Image)(resources.GetObject("Gray.Image")));
            this.Gray.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Gray.Location = new System.Drawing.Point(4, 308);
            this.Gray.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Gray.Name = "Gray";
            this.Gray.Size = new System.Drawing.Size(132, 30);
            this.Gray.TabIndex = 8;
            this.Gray.Text = "Gray";
            this.Gray.UseVisualStyleBackColor = false;
            this.Gray.Click += new System.EventHandler(this.Gray_Click);
            // 
            // Violet
            // 
            this.Violet.BackColor = System.Drawing.Color.Violet;
            this.Violet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Violet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Violet.Image = ((System.Drawing.Image)(resources.GetObject("Violet.Image")));
            this.Violet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Violet.Location = new System.Drawing.Point(4, 270);
            this.Violet.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Violet.Name = "Violet";
            this.Violet.Size = new System.Drawing.Size(132, 30);
            this.Violet.TabIndex = 7;
            this.Violet.Text = "Violet";
            this.Violet.UseVisualStyleBackColor = false;
            this.Violet.Click += new System.EventHandler(this.Violet_Click);
            // 
            // Blue
            // 
            this.Blue.BackColor = System.Drawing.Color.Blue;
            this.Blue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Blue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Blue.Image = ((System.Drawing.Image)(resources.GetObject("Blue.Image")));
            this.Blue.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Blue.Location = new System.Drawing.Point(4, 232);
            this.Blue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Blue.Name = "Blue";
            this.Blue.Size = new System.Drawing.Size(132, 30);
            this.Blue.TabIndex = 6;
            this.Blue.Text = "Blue";
            this.Blue.UseVisualStyleBackColor = false;
            this.Blue.Click += new System.EventHandler(this.Blue_Click);
            // 
            // Green
            // 
            this.Green.BackColor = System.Drawing.Color.Green;
            this.Green.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Green.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Green.Image = ((System.Drawing.Image)(resources.GetObject("Green.Image")));
            this.Green.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Green.Location = new System.Drawing.Point(4, 194);
            this.Green.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Green.Name = "Green";
            this.Green.Size = new System.Drawing.Size(132, 30);
            this.Green.TabIndex = 5;
            this.Green.Text = "Green";
            this.Green.UseVisualStyleBackColor = false;
            this.Green.Click += new System.EventHandler(this.Green_Click);
            // 
            // Yellow
            // 
            this.Yellow.BackColor = System.Drawing.Color.Yellow;
            this.Yellow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Yellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Yellow.ForeColor = System.Drawing.Color.Black;
            this.Yellow.Image = ((System.Drawing.Image)(resources.GetObject("Yellow.Image")));
            this.Yellow.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Yellow.Location = new System.Drawing.Point(4, 156);
            this.Yellow.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Yellow.Name = "Yellow";
            this.Yellow.Size = new System.Drawing.Size(132, 30);
            this.Yellow.TabIndex = 4;
            this.Yellow.Text = "Yellow";
            this.Yellow.UseVisualStyleBackColor = false;
            this.Yellow.Click += new System.EventHandler(this.Yellow_Click);
            // 
            // Orange
            // 
            this.Orange.BackColor = System.Drawing.Color.Orange;
            this.Orange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Orange.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Orange.Image = ((System.Drawing.Image)(resources.GetObject("Orange.Image")));
            this.Orange.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Orange.Location = new System.Drawing.Point(4, 118);
            this.Orange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Orange.Name = "Orange";
            this.Orange.Size = new System.Drawing.Size(132, 30);
            this.Orange.TabIndex = 3;
            this.Orange.Text = "Orange";
            this.Orange.UseVisualStyleBackColor = false;
            this.Orange.Click += new System.EventHandler(this.Orange_Click);
            // 
            // Red
            // 
            this.Red.BackColor = System.Drawing.Color.Red;
            this.Red.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Red.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Red.Image = ((System.Drawing.Image)(resources.GetObject("Red.Image")));
            this.Red.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Red.Location = new System.Drawing.Point(4, 80);
            this.Red.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Red.Name = "Red";
            this.Red.Size = new System.Drawing.Size(132, 30);
            this.Red.TabIndex = 2;
            this.Red.Text = "Red";
            this.Red.UseVisualStyleBackColor = false;
            this.Red.Click += new System.EventHandler(this.Red_Click);
            // 
            // Brown
            // 
            this.Brown.BackColor = System.Drawing.Color.Brown;
            this.Brown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Brown.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brown.Image = ((System.Drawing.Image)(resources.GetObject("Brown.Image")));
            this.Brown.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Brown.Location = new System.Drawing.Point(4, 42);
            this.Brown.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Brown.Name = "Brown";
            this.Brown.Size = new System.Drawing.Size(132, 30);
            this.Brown.TabIndex = 1;
            this.Brown.Text = "Brown";
            this.Brown.UseVisualStyleBackColor = false;
            this.Brown.Click += new System.EventHandler(this.Brown_Click);
            // 
            // Black
            // 
            this.Black.BackColor = System.Drawing.Color.Black;
            this.Black.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Black.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Black.Image = ((System.Drawing.Image)(resources.GetObject("Black.Image")));
            this.Black.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Black.Location = new System.Drawing.Point(4, 4);
            this.Black.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Black.Name = "Black";
            this.Black.Size = new System.Drawing.Size(132, 30);
            this.Black.TabIndex = 0;
            this.Black.Text = "Black";
            this.Black.UseVisualStyleBackColor = false;
            this.Black.Click += new System.EventHandler(this.Black_Click);
            // 
            // selectedColorsTxt
            // 
            this.selectedColorsTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.selectedColorsTxt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedColorsTxt.Location = new System.Drawing.Point(9, 398);
            this.selectedColorsTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.selectedColorsTxt.Name = "selectedColorsTxt";
            this.selectedColorsTxt.ReadOnly = true;
            this.selectedColorsTxt.Size = new System.Drawing.Size(267, 24);
            this.selectedColorsTxt.TabIndex = 55;
            this.selectedColorsTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UndoBtn
            // 
            this.UndoBtn.ForeColor = System.Drawing.Color.Black;
            this.UndoBtn.Image = ((System.Drawing.Image)(resources.GetObject("UndoBtn.Image")));
            this.UndoBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.UndoBtn.Location = new System.Drawing.Point(15, 22);
            this.UndoBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.UndoBtn.Name = "UndoBtn";
            this.UndoBtn.Size = new System.Drawing.Size(100, 46);
            this.UndoBtn.TabIndex = 15;
            this.UndoBtn.Text = "Undo";
            this.UndoBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.UndoBtn.UseVisualStyleBackColor = true;
            this.UndoBtn.Click += new System.EventHandler(this.UndoBtn_Click);
            // 
            // SixBandPanel3
            // 
            this.SixBandPanel3.Location = new System.Drawing.Point(51, 0);
            this.SixBandPanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel3.Name = "SixBandPanel3";
            this.SixBandPanel3.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel3.TabIndex = 42;
            // 
            // SixBandPanel5
            // 
            this.SixBandPanel5.Location = new System.Drawing.Point(93, 0);
            this.SixBandPanel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel5.Name = "SixBandPanel5";
            this.SixBandPanel5.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel5.TabIndex = 41;
            // 
            // SixBandPanel6
            // 
            this.SixBandPanel6.Location = new System.Drawing.Point(115, 0);
            this.SixBandPanel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel6.Name = "SixBandPanel6";
            this.SixBandPanel6.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel6.TabIndex = 40;
            // 
            // SixBandPanel1
            // 
            this.SixBandPanel1.Location = new System.Drawing.Point(8, 0);
            this.SixBandPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel1.Name = "SixBandPanel1";
            this.SixBandPanel1.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel1.TabIndex = 39;
            // 
            // SixBandPanel4
            // 
            this.SixBandPanel4.Location = new System.Drawing.Point(72, 0);
            this.SixBandPanel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel4.Name = "SixBandPanel4";
            this.SixBandPanel4.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel4.TabIndex = 44;
            // 
            // SixBandPanel2
            // 
            this.SixBandPanel2.Location = new System.Drawing.Point(29, 0);
            this.SixBandPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SixBandPanel2.Name = "SixBandPanel2";
            this.SixBandPanel2.Size = new System.Drawing.Size(13, 63);
            this.SixBandPanel2.TabIndex = 43;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(91, 58);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 16);
            this.label12.TabIndex = 50;
            this.label12.Text = "Tolerance:";
            // 
            // MinResistanceTxt
            // 
            this.MinResistanceTxt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinResistanceTxt.Location = new System.Drawing.Point(192, 85);
            this.MinResistanceTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MinResistanceTxt.Name = "MinResistanceTxt";
            this.MinResistanceTxt.ReadOnly = true;
            this.MinResistanceTxt.Size = new System.Drawing.Size(227, 24);
            this.MinResistanceTxt.TabIndex = 49;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(37, 89);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(131, 16);
            this.label25.TabIndex = 51;
            this.label25.Text = "Minimum Resistance";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(37, 119);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(138, 16);
            this.label26.TabIndex = 53;
            this.label26.Text = "Maximum Resistance:";
            // 
            // MaxResistanceTxt
            // 
            this.MaxResistanceTxt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxResistanceTxt.Location = new System.Drawing.Point(192, 112);
            this.MaxResistanceTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaxResistanceTxt.Name = "MaxResistanceTxt";
            this.MaxResistanceTxt.ReadOnly = true;
            this.MaxResistanceTxt.Size = new System.Drawing.Size(227, 24);
            this.MaxResistanceTxt.TabIndex = 52;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(12, 154);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(153, 16);
            this.label35.TabIndex = 54;
            this.label35.Text = "Temperature Coefficient:";
            // 
            // TempCoefficientTxt
            // 
            this.TempCoefficientTxt.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TempCoefficientTxt.Location = new System.Drawing.Point(192, 150);
            this.TempCoefficientTxt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TempCoefficientTxt.Name = "TempCoefficientTxt";
            this.TempCoefficientTxt.ReadOnly = true;
            this.TempCoefficientTxt.Size = new System.Drawing.Size(227, 24);
            this.TempCoefficientTxt.TabIndex = 55;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.FourBandPanel4);
            this.panel1.Controls.Add(this.FourBandPanel2);
            this.panel1.Controls.Add(this.FourBandPanel3);
            this.panel1.Controls.Add(this.FourBandPanel1);
            this.panel1.Location = new System.Drawing.Point(76, 133);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(136, 62);
            this.panel1.TabIndex = 56;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Location = new System.Drawing.Point(11, 158);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(265, 11);
            this.panel2.TabIndex = 57;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.FiveBandPanel3);
            this.panel3.Controls.Add(this.FiveBandPanel2);
            this.panel3.Controls.Add(this.FiveBandPanel4);
            this.panel3.Controls.Add(this.FiveBandPanel5);
            this.panel3.Controls.Add(this.FiveBandPanel1);
            this.panel3.Location = new System.Drawing.Point(76, 231);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(136, 62);
            this.panel3.TabIndex = 58;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Location = new System.Drawing.Point(11, 256);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(265, 11);
            this.panel7.TabIndex = 59;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.SixBandPanel1);
            this.panel4.Controls.Add(this.SixBandPanel4);
            this.panel4.Controls.Add(this.SixBandPanel6);
            this.panel4.Controls.Add(this.SixBandPanel5);
            this.panel4.Controls.Add(this.SixBandPanel3);
            this.panel4.Controls.Add(this.SixBandPanel2);
            this.panel4.Location = new System.Drawing.Point(76, 327);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 62);
            this.panel4.TabIndex = 60;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Location = new System.Drawing.Point(11, 352);
            this.panel11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(265, 11);
            this.panel11.TabIndex = 61;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.ResistanceTxt);
            this.groupBox1.Controls.Add(this.TempCoefficientTxt);
            this.groupBox1.Controls.Add(this.MinResistanceTxt);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.MaxResistanceTxt);
            this.groupBox1.Location = new System.Drawing.Point(613, 436);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(439, 182);
            this.groupBox1.TabIndex = 62;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Result";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.selectedColorsTxt);
            this.groupBox3.Controls.Add(this.panel5);
            this.groupBox3.Controls.Add(this.panel12);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.panel4);
            this.groupBox3.Controls.Add(this.panel11);
            this.groupBox3.Controls.Add(this.panel1);
            this.groupBox3.Controls.Add(this.panel3);
            this.groupBox3.Controls.Add(this.panel7);
            this.groupBox3.Controls.Add(this.panel2);
            this.groupBox3.Location = new System.Drawing.Point(765, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(287, 436);
            this.groupBox3.TabIndex = 63;
            this.groupBox3.TabStop = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(113, 20);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(49, 16);
            this.label37.TabIndex = 67;
            this.label37.Text = "3-band";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.ThreeBandPanel3);
            this.panel5.Controls.Add(this.ThreeBandPanel1);
            this.panel5.Controls.Add(this.ThreeBandPanel2);
            this.panel5.Location = new System.Drawing.Point(75, 43);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(136, 62);
            this.panel5.TabIndex = 65;
            // 
            // ThreeBandPanel3
            // 
            this.ThreeBandPanel3.Location = new System.Drawing.Point(87, 0);
            this.ThreeBandPanel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ThreeBandPanel3.Name = "ThreeBandPanel3";
            this.ThreeBandPanel3.Size = new System.Drawing.Size(13, 63);
            this.ThreeBandPanel3.TabIndex = 9;
            // 
            // ThreeBandPanel1
            // 
            this.ThreeBandPanel1.Location = new System.Drawing.Point(33, 0);
            this.ThreeBandPanel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ThreeBandPanel1.Name = "ThreeBandPanel1";
            this.ThreeBandPanel1.Size = new System.Drawing.Size(13, 63);
            this.ThreeBandPanel1.TabIndex = 9;
            // 
            // ThreeBandPanel2
            // 
            this.ThreeBandPanel2.Location = new System.Drawing.Point(60, 0);
            this.ThreeBandPanel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ThreeBandPanel2.Name = "ThreeBandPanel2";
            this.ThreeBandPanel2.Size = new System.Drawing.Size(13, 63);
            this.ThreeBandPanel2.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel12.Location = new System.Drawing.Point(9, 68);
            this.panel12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(265, 11);
            this.panel12.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(115, 308);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 64;
            this.label3.Text = "6-band";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(115, 209);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 16);
            this.label2.TabIndex = 63;
            this.label2.Text = "5-band";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(115, 110);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 62;
            this.label1.Text = "4-band";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this._6BandBtn);
            this.groupBox4.Controls.Add(this._3BandBtn);
            this.groupBox4.Controls.Add(this._5BandBtn);
            this.groupBox4.Controls.Add(this._4BandBtn);
            this.groupBox4.Location = new System.Drawing.Point(621, 15);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(128, 144);
            this.groupBox4.TabIndex = 64;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Choose a Band";
            // 
            // _6BandBtn
            // 
            this._6BandBtn.AutoSize = true;
            this._6BandBtn.ForeColor = System.Drawing.Color.Black;
            this._6BandBtn.Location = new System.Drawing.Point(16, 112);
            this._6BandBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._6BandBtn.Name = "_6BandBtn";
            this._6BandBtn.Size = new System.Drawing.Size(70, 20);
            this._6BandBtn.TabIndex = 67;
            this._6BandBtn.TabStop = true;
            this._6BandBtn.Text = "6-band";
            this._6BandBtn.UseVisualStyleBackColor = true;
            this._6BandBtn.CheckedChanged += new System.EventHandler(this._6BandBtn_CheckedChanged);
            // 
            // _3BandBtn
            // 
            this._3BandBtn.AutoSize = true;
            this._3BandBtn.ForeColor = System.Drawing.Color.Black;
            this._3BandBtn.Location = new System.Drawing.Point(16, 28);
            this._3BandBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._3BandBtn.Name = "_3BandBtn";
            this._3BandBtn.Size = new System.Drawing.Size(70, 20);
            this._3BandBtn.TabIndex = 55;
            this._3BandBtn.TabStop = true;
            this._3BandBtn.Text = "3-band";
            this._3BandBtn.UseVisualStyleBackColor = true;
            this._3BandBtn.CheckedChanged += new System.EventHandler(this._3BandBtn_CheckedChanged);
            // 
            // _5BandBtn
            // 
            this._5BandBtn.AutoSize = true;
            this._5BandBtn.ForeColor = System.Drawing.Color.Black;
            this._5BandBtn.Location = new System.Drawing.Point(16, 84);
            this._5BandBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._5BandBtn.Name = "_5BandBtn";
            this._5BandBtn.Size = new System.Drawing.Size(70, 20);
            this._5BandBtn.TabIndex = 66;
            this._5BandBtn.TabStop = true;
            this._5BandBtn.Text = "5-band";
            this._5BandBtn.UseVisualStyleBackColor = true;
            this._5BandBtn.CheckedChanged += new System.EventHandler(this._5BandBtn_CheckedChanged);
            // 
            // _4BandBtn
            // 
            this._4BandBtn.AutoSize = true;
            this._4BandBtn.ForeColor = System.Drawing.Color.Black;
            this._4BandBtn.Location = new System.Drawing.Point(16, 57);
            this._4BandBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._4BandBtn.Name = "_4BandBtn";
            this._4BandBtn.Size = new System.Drawing.Size(70, 20);
            this._4BandBtn.TabIndex = 65;
            this._4BandBtn.TabStop = true;
            this._4BandBtn.Text = "4-band";
            this._4BandBtn.UseVisualStyleBackColor = true;
            this._4BandBtn.CheckedChanged += new System.EventHandler(this._4BandBtn_CheckedChanged);
            // 
            // ResetBtn
            // 
            this.ResetBtn.ForeColor = System.Drawing.Color.Black;
            this.ResetBtn.Location = new System.Drawing.Point(15, 74);
            this.ResetBtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(100, 46);
            this.ResetBtn.TabIndex = 67;
            this.ResetBtn.Text = "Reset";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ResetBtn);
            this.groupBox5.Controls.Add(this.UndoBtn);
            this.groupBox5.Controls.Add(this.CalculateBtn);
            this.groupBox5.Location = new System.Drawing.Point(621, 177);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(128, 186);
            this.groupBox5.TabIndex = 68;
            this.groupBox5.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 623);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Color-Coded Resistor Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TempCoefficientImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToleranceImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MultiplierImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._3rdDigitImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._2ndDigitImg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._1stDigitImg)).EndInit();
            this.TemperatureCoefficient.ResumeLayout(false);
            this.TemperatureCoefficient.PerformLayout();
            this.Tolerance.ResumeLayout(false);
            this.Tolerance.PerformLayout();
            this.Multiplier.ResumeLayout(false);
            this.Multiplier.PerformLayout();
            this.ThirdDigit.ResumeLayout(false);
            this.ThirdDigit.PerformLayout();
            this.SecondDigit.ResumeLayout(false);
            this.SecondDigit.PerformLayout();
            this.FirstDigit.ResumeLayout(false);
            this.FirstDigit.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel FourBandPanel1;
        private System.Windows.Forms.Panel FourBandPanel2;
        private System.Windows.Forms.Panel FourBandPanel3;
        private System.Windows.Forms.Panel FourBandPanel4;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.TextBox ResistanceTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button UndoBtn;
        private System.Windows.Forms.Panel FiveBandPanel1;
        private System.Windows.Forms.Panel FiveBandPanel5;
        private System.Windows.Forms.Panel FiveBandPanel4;
        private System.Windows.Forms.Panel FiveBandPanel2;
        private System.Windows.Forms.Panel FiveBandPanel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel TemperatureCoefficient;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TableLayoutPanel Tolerance;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TableLayoutPanel Multiplier;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TableLayoutPanel ThirdDigit;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TableLayoutPanel SecondDigit;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TableLayoutPanel FirstDigit;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button Black;
        private System.Windows.Forms.Button Silver;
        private System.Windows.Forms.Button Gold;
        private System.Windows.Forms.Button White;
        private System.Windows.Forms.Button Gray;
        private System.Windows.Forms.Button Violet;
        private System.Windows.Forms.Button Blue;
        private System.Windows.Forms.Button Green;
        private System.Windows.Forms.Button Yellow;
        private System.Windows.Forms.Button Orange;
        private System.Windows.Forms.Button Red;
        private System.Windows.Forms.Button Brown;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.PictureBox TempCoefficientImg;
        private System.Windows.Forms.PictureBox ToleranceImg;
        private System.Windows.Forms.PictureBox MultiplierImg;
        private System.Windows.Forms.PictureBox _3rdDigitImg;
        private System.Windows.Forms.PictureBox _2ndDigitImg;
        private System.Windows.Forms.PictureBox _1stDigitImg;
        private System.Windows.Forms.Panel SixBandPanel3;
        private System.Windows.Forms.Panel SixBandPanel5;
        private System.Windows.Forms.Panel SixBandPanel6;
        private System.Windows.Forms.Panel SixBandPanel1;
        private System.Windows.Forms.Panel SixBandPanel4;
        private System.Windows.Forms.Panel SixBandPanel2;
        private System.Windows.Forms.Label SelectionGuideLbl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox MinResistanceTxt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox MaxResistanceTxt;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox TempCoefficientTxt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel ThreeBandPanel3;
        private System.Windows.Forms.Panel ThreeBandPanel1;
        private System.Windows.Forms.Panel ThreeBandPanel2;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RadioButton _6BandBtn;
        private System.Windows.Forms.RadioButton _5BandBtn;
        private System.Windows.Forms.RadioButton _4BandBtn;
        private System.Windows.Forms.RadioButton _3BandBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox selectedColorsTxt;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

